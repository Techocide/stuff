﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour
{
    //Defines the variables 
    public GameObject player;
    private Vector3 offset;
    public float smoothing = 5f;

    // Start is called before the first frame update
    void Start()
    {
        //offset so that the camera isn't inside the player
        offset = transform.position - player.transform.position;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        //calculaters where the camera should move to based off of the player's position
        Vector3 CamPos = player.transform.position + offset;
        //Smooths the camera
        transform.position = Vector3.Lerp(transform.position, CamPos, smoothing * Time.deltaTime);

       
    }
}
