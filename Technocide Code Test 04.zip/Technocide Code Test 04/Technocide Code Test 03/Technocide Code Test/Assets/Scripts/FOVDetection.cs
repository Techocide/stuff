﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;


public class FOVDetection : MonoBehaviour
{
    
    

    NavMeshAgent nav;

    public Transform player;
    public float maxAngle;
    public float maxRadius;

    public bool isInFOV = false;

    void Start()
    {
        nav = this.GetComponent<NavMeshAgent>();
    }
    
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, maxRadius);

        Vector3 fovLine1 = Quaternion.AngleAxis(maxAngle, transform.up) * transform.forward * maxRadius;
        Vector3 fovLine2 = Quaternion.AngleAxis(-maxAngle, transform.up) * transform.forward * maxRadius;

        Gizmos.color = Color.blue;
        Gizmos.DrawRay(transform.position, fovLine1);
        Gizmos.DrawRay(transform.position, fovLine2);

        if (!isInFOV)
        {
            Gizmos.color = Color.red;
        }
        else
        {
            Gizmos.color = Color.green;
            Attack();
        }
        Gizmos.DrawRay(transform.position, (player.position - transform.position).normalized * maxRadius);
        Gizmos.color = Color.black;
        Gizmos.DrawRay(transform.position, transform.forward * maxRadius);

    }


    public static bool inFOV(Transform checkObject, Transform target, float maxAngle, float maxRadius)
    {
        Collider[] overlaps = new Collider [10];
        int count = Physics.OverlapSphereNonAlloc(checkObject.position, maxRadius, overlaps);

        for (int i = 0; i < count; i++)
        {
            if (overlaps[i] != null)
            {
                if (overlaps[i].transform == target)
                {
                    Vector3 DirectionBetween = (target.position- checkObject.position).normalized;
                    DirectionBetween.y *= 0;

                    float angle = Vector3.Angle(checkObject.forward, DirectionBetween);

                    if (angle <= maxAngle)
                    {
                        Ray ray = new Ray(checkObject.position, target.position - checkObject.position);
                        RaycastHit hit;

                        if (Physics.Raycast(ray, out hit, maxRadius))
                        {
                            if (hit.transform == target)
                            {
                              
                                return true;
                            }
                        }
                    }

                }
            }
        }

        return false;
    }

    private void Update()
    {
        isInFOV = inFOV(transform, player, maxAngle, maxRadius);
       
            SetDestination();
        
    }
    private void SetDestination()
    {
        
            Vector3 targetVector = player.transform.position;
            nav.SetDestination(targetVector);
        
    }

    public void Attack()
    {

    }
}
