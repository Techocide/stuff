﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Shooting : MonoBehaviour
{
    [SerializeField]
  
    private float fireRate = 1.0f;

    [SerializeField]

    private int damage = 10;


    public ParticleSystem fire;
 
    private float timer;

   // public List<Enemy> enemies;
    public int enemyindex;
    //  public GameObject[] enemy;
    Enemy[] enemy;
    //EnemyHealth enemy;
    void Start()
    {
        fire = GetComponent<ParticleSystem>();
    }


    void FixedUpdate()
    {
        timer += Time.deltaTime;
        if (Input.GetButtonDown("Fire1"))
        {
            fire.Play();

            if (timer >= fireRate)
            {
                FireGun();
            }

        }
    }

    void FireGun()
    {
      Vector3 fwd = transform.TransformDirection(Vector3.forward);
      RaycastHit hit;

      if (Physics.Raycast(transform.position, fwd * 10, out hit, 20))
      {
        Debug.DrawRay(transform.position, fwd * 10, color: Color.yellow, 20);

            enemy.TakeDamage(damage);

        for (int i = 0; i >= 2; i++)
        {
           Debug.Log(1);
            /*
            if (hit.collider == enemies[i])
            {
                Debug.Log(2);
                 Enemy target = hit.collider.GetComponent<Enemy>();
                 target.TakeDamage(damage);
            }
            */
        }
      }

                Debug.Log("4");
                //fire.Play();
                timer = 0;
                //_enemy.TakeDamage(damage);

                print("There is something in front of the object!");


    }

}
    






// hit.collider.gameObject = GameObject.FindGameObjectWithTag("Enemy");

// Debug.Log("4");
//enemy.TakeDamage(damage);


/*
Debug.Log("1");
//Ray ray = new Ray(this.transform.position, fwd);
Debug.Log("2");
//RaycastHit hitInfo;

    Debug.Log("3");
    var CurrentHealth = hitInfo.collider.GetComponent<EnemyHealth>();

        if (CurrentHealth != null)
        {
          Debug.Log("4");
          CurrentHealth.TakeDamage(damage);

        }


*/
